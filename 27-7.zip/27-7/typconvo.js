        // Converting Strings to Numbers = STN
        // using - "number()"

        let STN1 = Number("99238781274871471247");
        document.getElementById("STN1").innerHTML = STN1 + "------is----" + typeof STN1;

        let STN2 = Number("Tempesto D Legion");
        document.getElementById('STN2').innerHTML = STN2 + "------is----" + typeof STN2;




        //converting Number to string = NTS
        // using 1- String(), 2- to.string()

        let NTS1 = String(1212312331243356789);
        document.getElementById('NTS1').innerHTML = NTS1 + "------is----" + typeof NTS1;

        let NTS2 = 6969696000;
        document.getElementById('NTS2').innerHTML = NTS2 + "------is----" + typeof NTS2.toString();




        // Converting Booleans to Numbers 

        let BTN1 = Number(false);
        document.getElementById("BTN1").innerHTML = BTN1 + "----false----" + typeof BTN1;

        let BTN2 = Number(true);
        document.getElementById("BTN2").innerHTML = BTN2 + "----true----" + typeof BTN2;



        // Converting Booleans to String

        let BTS1 = String(false);
        document.getElementById("BTS1").innerHTML = BTS1 + "----" + typeof BTS1;

        let BTS2 = String(true);
        document.getElementById("BTS2").innerHTML = BTS2 + "----" + typeof BTS2;

        //Automatic Type Conversion
        
        document.getElementById("auto").innerHTML =
            ( 72 + null) + "<br>" +
            ("5987" + null) + "<br>" +
            ("5" + 2) + "<br>" +
            ("5" - 2) + "<br>" ;